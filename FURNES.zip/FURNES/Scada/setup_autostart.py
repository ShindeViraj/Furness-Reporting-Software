import os
import subprocess

def setup_hidden_autostart():
    base_dir = r"C:\Users\HP\OneDrive\Desktop\FURNES\Scada"
    vbs_runner_path = os.path.join(base_dir, "start_scada_hidden.vbs")
    
    appdata = os.environ.get('APPDATA')
    startup_folder = os.path.join(appdata, r"Microsoft\Windows\Start Menu\Programs\Startup")
    shortcut_path = os.path.join(startup_folder, "Run_SCADA_Hidden.lnk")

    print("Setting up Invisible Auto-Start for SCADA System...")

    # 1. Create the Master VBScript that runs the commands invisibly
    vbs_runner_content = f"""Set WshShell = CreateObject("WScript.Shell")

' Start Node-RED silently
WshShell.Run "cmd.exe /c node-red", 0, False

' Wait 3 seconds to allow Node-RED to initialize
WScript.Sleep 3000

' Start Python Flask silently
WshShell.Run "cmd.exe /c cd /d ""{base_dir}"" && py app.py", 0, False
"""
    
    with open(vbs_runner_path, 'w', encoding='utf-8') as f:
        f.write(vbs_runner_content)
    print(f"  --> Created Hidden Runner script: {vbs_runner_path}")

    # 2. Create a temporary VBScript to create the Startup shortcut
    # FIXED: Replaced """" with Chr(34) to prevent Python Syntax Errors
    vbs_shortcut_creator = os.path.join(base_dir, "create_shortcut.vbs")
    vbs_shortcut_content = f"""Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = "{shortcut_path}"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = "wscript.exe"
oLink.Arguments = Chr(34) & "{vbs_runner_path}" & Chr(34)
oLink.WorkingDirectory = "{base_dir}"
oLink.Description = "Starts Node-RED and the SCADA Python Backend Silently"
oLink.Save
"""
    
    with open(vbs_shortcut_creator, 'w', encoding='utf-8') as f:
        f.write(vbs_shortcut_content)
        
    # Execute the script to create the shortcut
    subprocess.call(['cscript.exe', '//Nologo', vbs_shortcut_creator])
    
    # Clean up the temporary script
    os.remove(vbs_shortcut_creator)
    print(f"  --> Created new Startup Shortcut at: {shortcut_path}")
    
    # 3. Clean up the old visible shortcut if it exists
    old_shortcut = os.path.join(startup_folder, "Run_SCADA_System.lnk")
    if os.path.exists(old_shortcut):
        os.remove(old_shortcut)
        print("  --> Removed old visible startup shortcut.")
    
    print("\n✅ Invisible Auto-Start configured successfully!")
    print("On the next reboot, Node-RED and Python will start entirely in the background. No black screens will appear!")

if __name__ == "__main__":
    setup_hidden_autostart()