from flask import Flask, render_template, request, jsonify
import mysql.connector

app = Flask(__name__)

# Database configuration
DB_CONFIG = {
    'host': '127.0.0.1',
    'user': 'root', 
    'password': 'Shinde@123', 
    'database': 'furnance_test'
}

def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

def format_datetime(rows):
    for row in rows:
        if row.get('log_time'):
            row['log_time'] = row['log_time'].strftime('%Y-%m-%d %H:%M:%S')
    return rows

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/latest_cycle', methods=['GET'])
def get_latest_cycle():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    # 1. Find the ID of the absolute latest COMPLETED cycle
    cursor.execute("SELECT MAX(id) as last_id FROM heater_pv_log WHERE Cycle_end = 1")
    last_end_row = cursor.fetchone()
    last_end = last_end_row['last_id'] if last_end_row else None
    
    if not last_end:
        # If no cycle has ever ended, just fetch everything available
        cursor.execute("SELECT * FROM heater_pv_log ORDER BY id ASC")
        rows = cursor.fetchall()
    else:
        # 2. Find the end of the cycle right before it to act as the exact starting boundary
        cursor.execute("SELECT id FROM heater_pv_log WHERE Cycle_end = 1 AND id < %s ORDER BY id DESC LIMIT 1", (last_end,))
        prev_end_row = cursor.fetchone()
        prev_end = prev_end_row['id'] if prev_end_row else 0
        
        # 3. STRICTLY fetch only the last completed cycle (Ignoring the ongoing data)
        cursor.execute("SELECT * FROM heater_pv_log WHERE id >= %s AND id <= %s ORDER BY id ASC", (prev_end, last_end))
        rows = cursor.fetchall()
        
    cursor.close()
    conn.close()
    
    return jsonify(format_datetime(rows))

@app.route('/api/date_range', methods=['POST'])
def get_date_range():
    data = request.json
    start_date = data.get('start')
    end_date = data.get('end')
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    query = "SELECT * FROM heater_pv_log WHERE log_time >= %s AND log_time <= %s ORDER BY log_time ASC"
    cursor.execute(query, (start_date + " 00:00:00", end_date + " 23:59:59"))
    rows = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return jsonify(format_datetime(rows))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
